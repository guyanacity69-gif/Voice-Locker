package com.example.voicelocker;

import android.Manifest;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.content.Intent;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Typeface;
import android.graphics.Color;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status, phraseView;
    private EditText phraseInput;
    private SpeechRecognizer recognizer;
    private boolean enrolling = false;
    private static final int MIC_REQ = 42;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("voice_locker", MODE_PRIVATE);
        buildUi();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 48, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(248,250,252));

        TextView title = new TextView(this);
        title.setText("🔐  Voice Locker");
        title.setTextSize(28); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(15,23,42));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Apna voice passphrase set karo, phir bolkar unlock karo.");
        sub.setTextSize(15); sub.setTextColor(Color.DKGRAY);
        sub.setGravity(Gravity.CENTER); sub.setPadding(0,18,0,28);
        root.addView(sub);

        phraseView = new TextView(this);
        phraseView.setText("Saved passphrase: " + (prefs.contains("phrase") ? "••••••••" : "Not set"));
        phraseView.setTextSize(16); phraseView.setTextColor(Color.rgb(51,65,85));
        root.addView(phraseView);

        phraseInput = new EditText(this);
        phraseInput.setSingleLine(true);
        phraseInput.setHint("Example: open my locker");
        phraseInput.setTextSize(16);
        root.addView(phraseInput, new LinearLayout.LayoutParams(-1, -2));

        Button save = new Button(this);
        save.setText("Save voice passphrase");
        root.addView(save);
        save.setOnClickListener(v -> {
            String p = phraseInput.getText().toString().trim().toLowerCase(Locale.ROOT);
            if (p.length() < 3) { show("Kam se kam 3 characters ka phrase likho."); return; }
            prefs.edit().putString("phrase", p).apply();
            phraseView.setText("Saved passphrase: ••••••••");
            phraseInput.setText("");
            show("Passphrase saved. Ab unlock karke dekho.");
        });

        Button unlock = new Button(this);
        unlock.setText("🎙  Speak to unlock");
        root.addView(unlock);
        unlock.setOnClickListener(v -> startListening(false));

        status = new TextView(this);
        status.setText("Status: Locked");
        status.setTextSize(20); status.setTypeface(null, Typeface.BOLD);
        status.setTextColor(Color.rgb(185,28,28));
        status.setGravity(Gravity.CENTER); status.setPadding(0,30,0,12);
        root.addView(status);

        TextView note = new TextView(this);
        note.setText("Important: Yeh demo bole gaye words/passphrase ko match karta hai, speaker ki asli awaaz ya identity ko nahi. Recording/replay se bypass ho sakta hai; sensitive cheezon ki security ke liye ise use na karein.");
        note.setTextSize(12); note.setTextColor(Color.rgb(100,116,139));
        note.setPadding(0,24,0,0);
        root.addView(note);
        setContentView(root);
    }

    private void startListening(boolean setup) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("Is phone par speech recognition available nahi hai."); return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQ); return;
        }
        if (!prefs.contains("phrase")) { show("Pehle passphrase save karo."); return; }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        status.setText("Listening…");
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onError(int e) { show("Voice samajh nahi aayi. Dobara try karo."); }
            public void onResults(Bundle b) {
                ArrayList<String> results = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String expected = prefs.getString("phrase", "").trim().toLowerCase(Locale.ROOT);
                boolean ok = false;
                if (results != null) for (String s : results)
                    if (s.trim().toLowerCase(Locale.ROOT).equals(expected)) ok = true;
                if (ok) {
                    status.setText("🔓 Unlocked (demo)");
                    status.setTextColor(Color.rgb(22,163,74));
                } else show("Phrase match nahi hua. Locked.");
                if (recognizer != null) { recognizer.destroy(); recognizer = null; }
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle p) {}
        });
        recognizer.startListening(intent);
    }

    private void show(String message) {
        status.setText(message);
        status.setTextColor(Color.rgb(185,28,28));
    }
    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        super.onDestroy();
    }
}
